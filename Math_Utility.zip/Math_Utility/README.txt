This utility will find:
the maximum number in the file;
the minimum number in the file;
median;
arithmetic mean.
works with files in ".txt" format
"Example file" added.